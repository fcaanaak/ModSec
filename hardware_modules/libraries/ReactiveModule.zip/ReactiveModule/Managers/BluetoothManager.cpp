#include "BluetoothManager.h"


void BluetoothManager::openConnection(){

  
}

void BluetoothManager::closeConnection(){


}

void BluetoothManager::setup(){

  

}
